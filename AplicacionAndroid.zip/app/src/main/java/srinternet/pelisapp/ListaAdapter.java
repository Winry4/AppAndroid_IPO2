package srinternet.pelisapp;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Rebeca on 21/05/2018.
 */

public class ListaAdapter extends BaseAdapter{
    private List<Peliculas> listaPelis;
    GridView gridView;
    private LayoutInflater inflater;
   Activity a;

    public ListaAdapter(List<Peliculas> listaPelis, Activity a) {
        this.listaPelis = listaPelis;
        this.a=a;
    }

    @Override
    public int getCount() {
       return listaPelis.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater==null){
            inflater=(LayoutInflater)a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if (view==null){
            view=inflater.inflate(R.layout.lista_pelis,null);
        }
        RelativeLayout relativeLayout=(RelativeLayout) inflater.inflate(R.layout.activity_main,null);
        gridView=(GridView)relativeLayout.findViewById(R.id.ListaPelis);

        final ImageView image = (ImageView) view.findViewById(R.id.fotoPeli);
        TextView nombre=(TextView) view.findViewById(R.id.titulo);
        TextView duracion=(TextView) view.findViewById(R.id.duracion);

        final Peliculas la=listaPelis.get(i);

        //image.setImageBitmap(la.getImagen());
        nombre.setText(la.getNombre());
        duracion.setText(la.getDuracion());


        return view;
    }
    public Bitmap redimensionarImagenMaximo(Bitmap mBitmap, float newWidth, float newHeigth){
        //Redimensionamos
        int width = mBitmap.getWidth();
        int height = mBitmap.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeigth) / height;
        // create a matrix for the manipulation
        Matrix matrix = new Matrix();
        // resize the bit map
        matrix.postScale(scaleWidth, scaleHeight);
        // recreate the new Bitmap
        return Bitmap.createBitmap(mBitmap, 0, 0, width, height, matrix, false);
    }
}
