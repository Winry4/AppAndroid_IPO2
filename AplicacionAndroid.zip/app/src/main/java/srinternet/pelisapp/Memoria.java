package srinternet.pelisapp;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rebeca on 21/05/2018.
 */

public class Memoria {
    public static List<Peliculas> ListaPeliculas=new ArrayList<>();

}
